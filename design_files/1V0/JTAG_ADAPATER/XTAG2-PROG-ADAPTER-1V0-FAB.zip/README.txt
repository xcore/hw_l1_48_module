README.txt
----------
 
Additional information relating to the build of design XTAG2-PROG-ADAPTER-1V0
 
Design Ref : XTAG2-PROG-ADAPTER-1V0
 
Contact : Corin Rathbone
Tel(UK) : 0117 915 4225
Email   : corin@xmos.com
Address : XMOS Limited
          Venturers House
          King Street
          Bristol
          United Kingdom
          BS1 4PB
 
PCB Design tool : KiCAD PCBnew
 
Description of files included in XTAG2-PROG-ADAPTER-1V0-FAB.zip:
 
./README.txt    This file.
 
./BOM/      This directory contains the bill of materials and component position files for fabrication.
 
XTAG2-PROG-ADAPTER-1V0.lst    Component Reference List
XTAG2-PROG-ADAPTER-1V0-BOM.xls    Bill Of Materials
 
./Drill/        This directory contains the following drill data files for the design.
 
XTAG2-PROG-ADAPTER-1V0-NC.drl     NC Drill File (Excellon Format, metric (000.00), suppress trailing zeros, absolute coordinates)
XTAG2-PROG-ADAPTER-1V0-NC.rep     NC Drill Report (Sizes & Quantities)
XTAG2-PROG-ADAPTER-1V0-NC.ps      Drill Diagram in postscript.
 
./Gerber/       This directory contains the following gerber files for the design in RS-274-X format.
 
XTAG2-PROG-ADAPTER-1V0-Ln.pho     PCB Copper Layer (where n = layer number, 01=Top Side)
XTAG2-PROG-ADAPTER-1V0-SST.pho    Silkscreen Top
XTAG2-PROG-ADAPTER-1V0-SSB.pho    Silkscreen Bottom
XTAG2-PROG-ADAPTER-1V0-SMT.pho    Solder Mask Top
XTAG2-PROG-ADAPTER-1V0-SMB.pho    Solder Mask Bottom
XTAG2-PROG-ADAPTER-1V0-SPT.pho    Solder Paste Top
XTAG2-PROG-ADAPTER-1V0-SPB.pho    Solder Paste Bottom
XTAG2-PROG-ADAPTER-1V0-FAB.pho    Fabrication Instructions
XTAG2-PROG-ADAPTER-1V0-AST.pho    Assembly Diagram Top
XTAG2-PROG-ADAPTER-1V0-ASB.pho    Assembly Diagram Bottom
 
./Netlist/      This directory contains the netlist files for equivalence checking and bare board test.
 
XTAG2-PROG-ADAPTER-1V0.net    OrCad Format Netlist
