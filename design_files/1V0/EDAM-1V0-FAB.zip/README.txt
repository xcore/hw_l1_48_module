README.txt
----------

Additional information relating to the build of design XPCB-038.

Design Ref : EDAM-1V0 (XPCB-038)

Contact : Corin Rathbone
Tel(UK) : 0117 9154225
Email   : corin@xmos.com
Address : XMOS Limited
          Venturers House
          King Street
          Bristol
          United Kingdom
          BS1 4PB

PCB Design tool : Mentor Graphics PADS9.3 Flow. DxDesigner, PADS Layout.


Description of files included in XPCB-038-FAB.zip:

./README.txt    This file.

./BOM/      This directory contains the bill of materials and component position files for fabrication.

XPCB-038.pos        Component Position Data
XPCB-038.xls        Bill Of Materials

./Gerber/       This directory contains the following gerber files for the design in RS-274-X format.
      
XPCB-038-Ln.pho     PCB Copper Layer (where n = layer number, 01=Top Side)
XPCB-038-SST.pho    Silkscreen Top
XPCB-038-SSB.pho    Silkscreen Bottom  
XPCB-038-SMT.pho    Solder Mask Top
XPCB-038-SMB.pho    Solder Mask Bottom
XPCB-038-SPT.pho    Solder Paste Top
XPCB-038-SPB.pho    Solder Paste Bottom
XPCB-038-FAB.pho    Fabrication Instructions
XPCB-038-DRL.pho    Drill Diagram

./Drill/        This directory contains the following drill data files for the design.

XPCB-038-NC.drl     NC Drill File (Excellon Format, metric (000.00), suppress trailing zeros, absolute coordinates)
XPCB-038-NC.rep     NC Drill Report (Sizes & Quantities)
XPCB-038-NC.lst     NC Drill List (Sizes & Coordinates)

./Netlist/      This directory contains the netlist files for equivalence checking and bare board test.

XPCB-038-IPC.net    IPC-D-356 Format Netlist
